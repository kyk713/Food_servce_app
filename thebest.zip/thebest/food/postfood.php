<?php

$host = "127.0.0.1";
$username = "root";
$password = "usbw";
$dbname =  "food_system";

// Connect to server
$connect=mysql_connect($host, $username, $password, $dbname) 
                    or die ("Sorry, unable to connect database server");

$dbselect=mysql_select_db($dbname,$connect) 
                    or die ("Sorry, unable to connect database");
					

$Foodname  = $_POST["Foodname"];
$Price = $_POST["Price"];
$Cname = $_POST["Cname"];
$Phone = $_POST["Phone"];
$Address = $_POST["Address"];
$Size = $_POST["Size"];


// Run the query
$query = "INSERT INTO food (foodname, price, cname, phone, address, size)" .
       			   " values ('$Foodname', '$Price', '$Cname', '$Phone', '$Address', '$Size')";

$result = mysql_query($query);

if ($result) {
    print "registration success";
} else {
    print "Failed!";
}

mysql_close();
?>





