

<?php
$host = "127.0.0.1";
$username = "root";
$password = "usbw";   // default password for "root" user is empty
$dbname =  "food_system";


// Connect to server
$connect=mysql_connect($host, $username, $password) 
                    or die ("Sorry, unable to connect database server");

$dbselect=mysql_select_db($dbname,$connect) 
                    or die ("Sorry, unable to connect database");

// Run the query
$result = mysql_query("SELECT * FROM food");

if ($result) {

//   while ($row = mysql_fetch_array($result)) {
//      $id         = $row["id"];
//      $food_name     = $row["food_name"];
//      $price    = $row["price"];
//      $cname    = $row["cname"];
//      $phone    = $row["phone"];
//      $address    = $row["address"];
//      $size    = $row["size"];
//   }



    while ($row = mysql_fetch_assoc($result)) {
	$output[] = $row;
    }

    print("{\"food\":");
    print(json_encode($output));
    print("}");
}

mysql_close();
?>

