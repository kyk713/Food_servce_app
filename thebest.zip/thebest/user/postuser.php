<?php

$host = "127.0.0.1";
$username = "root";
$password = "usbw";   
$dbname =  "login_system";

// Connect to server
$connect=mysql_connect($host, $username, $password) 
                    or die ("Sorry, unable to connect database server");

$dbselect=mysql_select_db($dbname,$connect) 
                    or die ("Sorry, unable to connect database");
					

$Name  = $_POST["Name"];
$Password = $_POST["Password"];
$Email = $_POST["Email"];


// Run the query
$query = "insert into user (name, password, email)" .
       			   " values ('$Name', '$Password', '$Email')";

$result = mysql_query($query);

if ($result) {
    print "registration success";
} else {
    print "Failed!";
}

mysql_close();
?>





